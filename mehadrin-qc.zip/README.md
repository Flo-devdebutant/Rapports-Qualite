# Mehadrin QC — application de contrôle qualité fruits & légumes

Application web installable (PWA) pour saisir, partager et exploiter les rapports
de contrôle qualité : **réception** (lot fournisseur à l'arrivée) et **expédition
client** (contrôle avant départ). Les rapports sont partagés entre tous les
membres de l'équipe via une base de données hébergée en France.

---

## 1. Ce que fait l'application

| | |
|---|---|
| **Rapports** | Réception et expédition, avec en-tête complet (date + n° de semaine, dépôt, origine, commande, id de chargement, lot, catégorie, palette problématique) |
| **Produits** | Avocat et Mangue livrés avec leurs grilles, plus un gabarit générique « Fruits & légumes ». Tout est modifiable, et on ajoute autant de produits qu'on veut |
| **Critères** | Mesures numériques, pourcentages de défauts, listes de choix, conforme/non conforme — chacun avec ses seuils et sa gravité (mineur, majeur, critique) |
| **Verdict** | Qualité · Conservabilité · Évaluation · %NC · note sur 5, calculés en direct pendant la saisie |
| **Photos** | Prise de vue depuis le téléphone, compressées automatiquement (~200 ko), jusqu'à 12 par rapport |
| **Hors-ligne** | Saisie complète sans réseau, envoi automatique au retour de la connexion |
| **PDF** | Mise en page professionnelle au logo Mehadrin, en français, anglais, italien, espagnol ou néerlandais |
| **Partage** | WhatsApp, e-mail, SMS via le partage natif du téléphone ; téléchargement sur ordinateur |
| **Excel** | Export deux feuilles : un rapport par ligne + une ligne par mesure (pour tableaux croisés dynamiques) |
| **Statistiques** | Taux de non-conformité par fournisseur, produit et origine ; défauts les plus fréquents |
| **Équipe** | Trois rôles : administrateur, inspecteur, lecture seule. Tout nouveau compte doit être validé par un administrateur |

---

## 2. Mise en service (une seule fois, ~10 minutes)

### Étape 1 — La base de données est déjà prête

Le projet Supabase **`mehadrin-qc`** est créé, en **région Paris (eu-west-3)**, avec :

- les tables (`profiles`, `reports`, `partners`, `product_groups`, `settings`) ;
- les règles de sécurité (RLS) : **un compte non validé ne lit rien et n'écrit rien** ;
- le stockage privé des photos (accès par lien signé d'une heure).

Ces réglages sont déjà appliqués. Rien à faire ici.

### Étape 2 — Désactiver la confirmation par e-mail ⚠️ *important*

Par défaut, Supabase exige qu'un nouvel inscrit clique sur un lien reçu par e-mail.
C'est inutile ici (**la validation par un administrateur joue déjà ce rôle**) et
bloquant en pratique : le service d'envoi gratuit de Supabase est limité à quelques
messages par heure et n'écrit qu'aux membres du projet.

1. Ouvrir <https://supabase.com/dashboard/project/tezqfezcziyarxnekxbu/auth/providers>
2. Section **Email** → décocher **Confirm email** → **Save**

Si vous préférez la garder activée, il faudra brancher un vrai service SMTP
(onglet *Authentication → Emails → SMTP Settings*).

### Étape 3 — Publier l'application

Les fichiers sont statiques : n'importe quel hébergeur convient.

**GitHub Pages** (gratuit, comme votre application de budget) :

1. Créer un dépôt, par exemple `mehadrin-qc`.
2. Y déposer **tout le contenu** de ce dossier (`index.html` doit être à la racine).
3. *Settings → Pages → Source: Deploy from a branch → main / (root)* → **Save**.
4. L'adresse est `https://<votre-compte>.github.io/mehadrin-qc/`.

**Autres options** : Netlify ou Vercel (glisser-déposer du dossier), ou tout
hébergement web classique. Une seule condition : **servir en HTTPS**, sans quoi
ni l'appareil photo ni le mode hors-ligne ne fonctionnent.

### Étape 4 — Créer le compte administrateur

Ouvrir l'adresse, cliquer **Créer un compte**, saisir nom, e-mail, mot de passe.

> **Le tout premier compte créé devient automatiquement administrateur et validé.**
> Faites-le vous-même, avant de communiquer l'adresse à l'équipe.

À la première connexion, les grilles Avocat, Mangue et Fruits & légumes sont
installées automatiquement.

### Étape 5 — L'équipe

Chaque collègue ouvre la même adresse et crée son compte. Il voit alors
« Compte en attente ». Vous l'activez dans **Réglages → Équipe**, en lui
attribuant son rôle.

---

## 3. Installer sur le téléphone

- **Android / Chrome** : menu ⋮ → *Installer l'application* (ou *Ajouter à l'écran d'accueil*).
- **iPhone / Safari** : bouton Partager → *Sur l'écran d'accueil*.

L'application s'ouvre alors en plein écran, sans barre d'adresse, et démarre
sans réseau. Trois raccourcis sont disponibles par appui long sur l'icône :
réception, expédition, flux.

---

## 4. Comment le verdict est calculé

Chaque critère reçoit un statut : **vert** (dans les seuils), **orange**
(à surveiller), **rouge** (hors seuil). La gravité du critère décide de ce
qui arrive quand il sort du vert :

- **mineur** → orange ;
- **majeur** → rouge, pèse sur la qualité ;
- **critique** → rouge et **non-conformité directe** (pourriture, anthracnose…).

Trois sorties indépendantes en découlent :

| Axe | Valeurs | Ce qu'il dit |
|---|---|---|
| **Qualité** | Bonne / Moyenne / Mauvaise | l'état de la marchandise maintenant |
| **Conservabilité** | Élevée / Moyenne / Minimale | combien de temps elle va tenir (fermeté, température, maladies évolutives) |
| **Évaluation** | Conforme / Acceptable / Non Conforme | %NC comparé à la tolérance de la catégorie |

Le **%NC** se calcule tout seul à partir de *caisses problématiques ÷ caisses
échantillon*, et reste modifiable à la main si vous avez votre propre comptage.
La tolérance par défaut est de **10 %**, ce qui correspond à la catégorie I des
normes CEE-ONU ; elle se règle par produit.

### Origine des seuils livrés

- **Avocat** — CEE-ONU FFV-42 : matière sèche minimale 21 % (Hass), 20 %
  (Fuerte, Pinkerton, Reed, Edranol), 19 % (autres variétés) ; tolérance 10 % de
  défauts, 1 % de pourriture ; calibres 4 à 32 et S.
- **Mangue** — CEE-ONU FFV-45 : calibres A à D, Brix de référence ≈ 14, tolérance
  10 % de défauts.

Ce sont des points de départ : ajustez-les avec vos clients dans
**Réglages → Produits & critères**. Les cahiers des charges d'un distributeur
priment souvent sur les minima réglementaires.

> Un rapport enregistré **conserve une copie de la grille utilisée**. Si vous
> modifiez un seuil l'année prochaine, les anciens rapports restent lisibles tels
> qu'ils ont été établis.

---

## 5. Organisation des fichiers

```
index.html                 page unique
manifest.webmanifest       déclaration PWA (icônes, raccourcis)
sw.js                      service worker — cache hors-ligne
logo.svg                   logo Mehadrin (interface + PDF)
icons/                     icônes d'application
css/app.css                styles (mode sombre inclus)
js/
  config.js                adresse et clé de la base   ← le seul fichier à changer
  app.js                   amorçage, connexion, routeur, accueil
  supa.js                  client Supabase minimal (auth, données, stockage)
  store.js                 base locale IndexedDB + synchronisation
  verdict.js               calcul des statuts et du verdict
  catalog.js               grilles par défaut avocat / mangue / générique
  ui.js                    briques d'interface, compression photo, partage
  pdf.js                   moteur PDF
  report-pdf.js            mise en page du rapport + traductions
  xlsx.js                  export Excel
  screens/                 formulaire, flux et fiche, réglages, statistiques
```

Aucune bibliothèque externe, aucun CDN, rien à compiler : l'application démarre
même sans réseau dès la première visite mise en cache.

---

## 6. Mettre à jour l'application

Remplacer les fichiers sur l'hébergeur, puis **changer la ligne `CACHE` en haut
de `sw.js`** (`mehadrin-qc-v1` → `v2`, etc.). Sans ce changement, les téléphones
continueraient de servir l'ancienne version depuis leur cache.

---

## 7. Données personnelles

- Hébergement **Supabase, région Paris (eu-west-3)** : aucun transfert hors UE.
- Les photos sont dans un stockage **privé** ; leur consultation passe par un lien
  signé valable une heure.
- Données conservées : nom, e-mail et rôle des utilisateurs, plus le contenu des
  rapports. Aucun suivi publicitaire, aucun traceur tiers.
- Un administrateur peut suspendre un accès ou supprimer un compte dans
  **Réglages → Équipe**.
- À définir de votre côté : la **durée de conservation** des rapports et des photos
  (l'usage est de couvrir la durée de la relation commerciale plus le délai de
  prescription des réclamations).

---

## 8. Limites connues

- Le partage direct vers WhatsApp utilise le partage natif du téléphone ; sur
  ordinateur, le PDF est téléchargé puis à joindre manuellement.
- Les notifications automatiques sur rapport non conforme ne sont pas encore
  branchées (prévu à l'étape 2 du cahier des charges).
- L'interface est en français ; seul le PDF est traduit, puisque c'est lui qui
  sort de l'entreprise.
